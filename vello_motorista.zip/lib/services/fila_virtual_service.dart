
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:geolocator/geolocator.dart';
import 'dart:async';
import 'dart:math';

class FilaVirtualService extends ChangeNotifier {
  static final FilaVirtualService _instance = FilaVirtualService._internal();
  factory FilaVirtualService() => _instance;
  FilaVirtualService._internal();

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  String? _posicaoAtualNaFila;
  List<Map<String, dynamic>> _pontosEstrategicos = [];
  Map<String, dynamic>? _pontoAtual;
  Timer? _timerAtualizacao;
  bool _naFila = false;
  int _tempoEsperaEstimado = 0;

  // Getters
  String? get posicaoAtualNaFila => _posicaoAtualNaFila;
  List<Map<String, dynamic>> get pontosEstrategicos => _pontosEstrategicos;
  Map<String, dynamic>? get pontoAtual => _pontoAtual;
  bool get naFila => _naFila;
  int get tempoEsperaEstimado => _tempoEsperaEstimado;

  // Inicializar serviço
  Future<void> inicializar() async {
    await _carregarPontosEstrategicos();
    _iniciarMonitoramento();
  }

  // Entrar na fila do ponto mais próximo
  Future<bool> entrarNaFila(Position posicaoMotorista) async {
    try {
      final pontoMaisProximo = await _encontrarPontoMaisProximo(posicaoMotorista);

      if (pontoMaisProximo == null) {
        return false;
      }

      final motoristaId = FirebaseAuth.instance.currentUser?.uid;
      if (motoristaId == null) return false;

      // Adicionar à fila do ponto
      await _firestore.collection('fila_virtual').add({
        'motoristaId': motoristaId,
        'pontoId': pontoMaisProximo['id'],
        'posicao': {
          'lat': posicaoMotorista.latitude,
          'lon': posicaoMotorista.longitude,
        },
        'entradaEm': FieldValue.serverTimestamp(),
        'status': 'aguardando',
        'prioridade': await _calcularPrioridade(motoristaId),
      });

      _pontoAtual = pontoMaisProximo;
      _naFila = true;

      await _atualizarPosicaoNaFila();
      notifyListeners();

      return true;
    } catch (e) {
      print('Erro ao entrar na fila: $e');
      return false;
    }
  }

  // Sair da fila
  Future<void> sairDaFila() async {
    try {
      final motoristaId = FirebaseAuth.instance.currentUser?.uid;
      if (motoristaId == null) return;

      final querySnapshot = await _firestore
          .collection('fila_virtual')
          .where('motoristaId', isEqualTo: motoristaId)
          .where('status', isEqualTo: 'aguardando')
          .get();

      for (var doc in querySnapshot.docs) {
        await doc.reference.delete();
      }

      _naFila = false;
      _posicaoAtualNaFila = null;
      _pontoAtual = null;
      _tempoEsperaEstimado = 0;

      notifyListeners();
    } catch (e) {
      print('Erro ao sair da fila: $e');
    }
  }

  // Encontrar ponto estratégico mais próximo
  Future<Map<String, dynamic>?> _encontrarPontoMaisProximo(Position posicao) async {
    if (_pontosEstrategicos.isEmpty) return null;

    double menorDistancia = double.infinity;
    Map<String, dynamic>? pontoMaisProximo;

    for (var ponto in _pontosEstrategicos) {
      final distancia = Geolocator.distanceBetween(
        posicao.latitude,
        posicao.longitude,
        ponto['lat'],
        ponto['lon'],
      );

      if (distancia < menorDistancia && distancia <= 500) { // Máximo 500m
        menorDistancia = distancia;
        pontoMaisProximo = ponto;
      }
    }

    return pontoMaisProximo;
  }

  // Carregar pontos estratégicos
  Future<void> _carregarPontosEstrategicos() async {
    try {
      final querySnapshot = await _firestore.collection('pontos_estrategicos').get();

      _pontosEstrategicos = querySnapshot.docs.map((doc) {
        final data = doc.data();
        data['id'] = doc.id;
        return data;
      }).toList();

      // Se não há pontos cadastrados, criar pontos padrão
      if (_pontosEstrategicos.isEmpty) {
        await _criarPontosPadrao();
      }

      notifyListeners();
    } catch (e) {
      print('Erro ao carregar pontos estratégicos: $e');
      await _criarPontosPadrao();
    }
  }

  // Criar pontos padrão (principais locais de SP)
  Future<void> _criarPontosPadrao() async {
    final pontosPadrao = [
      {
        'nome': 'Aeroporto Congonhas',
        'lat': -23.6256,
        'lon': -46.6563,
        'tipo': 'aeroporto',
        'capacidade': 50,
        'demandaMedia': 0.8,
      },
      {
        'nome': 'Aeroporto Guarulhos',
        'lat': -23.4356,
        'lon': -46.4731,
        'tipo': 'aeroporto',
        'capacidade': 100,
        'demandaMedia': 0.9,
      },
      {
        'nome': 'Shopping Ibirapuera',
        'lat': -23.6075,
        'lon': -46.6625,
        'tipo': 'shopping',
        'capacidade': 30,
        'demandaMedia': 0.6,
      },
      {
        'nome': 'Terminal Rodoviário Tietê',
        'lat': -23.5139,
        'lon': -46.6347,
        'tipo': 'rodoviaria',
        'capacidade': 40,
        'demandaMedia': 0.7,
      },
      {
        'nome': 'Estação da Luz',
        'lat': -23.5344,
        'lon': -46.6358,
        'tipo': 'estacao',
        'capacidade': 25,
        'demandaMedia': 0.6,
      },
    ];

    try {
      for (var ponto in pontosPadrao) {
        await _firestore.collection('pontos_estrategicos').add(ponto);
      }
      await _carregarPontosEstrategicos();
    } catch (e) {
      print('Erro ao criar pontos padrão: $e');
    }
  }

  // Calcular prioridade do motorista
  Future<double> _calcularPrioridade(String motoristaId) async {
    try {
      double prioridade = 1.0;

      // Histórico de avaliações
      final avaliacoes = await _obterAvaliacoesMotorista(motoristaId);
      if (avaliacoes > 4.5) {
        prioridade += 0.3;
      } else if (avaliacoes < 4.0) {
        prioridade -= 0.2;
      }

      // Tempo como motorista
      final tempoMotorista = await _obterTempoComoMotorista(motoristaId);
      prioridade += (tempoMotorista / 365) * 0.1; // +0.1 por ano

      // Número de corridas recentes
      final corridasRecentes = await _obterCorridasRecentes(motoristaId);
      prioridade += (corridasRecentes / 100) * 0.2;

      return prioridade.clamp(0.1, 3.0);
    } catch (e) {
      return 1.0;
    }
  }

  // Atualizar posição na fila
  Future<void> _atualizarPosicaoNaFila() async {
    try {
      final motoristaId = FirebaseAuth.instance.currentUser?.uid;
      if (motoristaId == null || _pontoAtual == null) return;

      final querySnapshot = await _firestore
          .collection('fila_virtual')
          .where('pontoId', isEqualTo: _pontoAtual!['id'])
          .where('status', isEqualTo: 'aguardando')
          .orderBy('prioridade', descending: true)
          .orderBy('entradaEm')
          .get();

      int posicao = 0;
      for (int i = 0; i < querySnapshot.docs.length; i++) {
        if (querySnapshot.docs[i]['motoristaId'] == motoristaId) {
          posicao = i + 1;
          break;
        }
      }

      _posicaoAtualNaFila = posicao > 0 ? '$posicao° na fila' : 'Fora da fila';
      _tempoEsperaEstimado = _calcularTempoEspera(posicao);

      notifyListeners();
    } catch (e) {
      print('Erro ao atualizar posição na fila: $e');
    }
  }

  // Calcular tempo estimado de espera
  int _calcularTempoEspera(int posicao) {
    if (posicao <= 0) return 0;

    // Estima 3-5 minutos por posição à frente
    final tempoMedioPorPosicao = 4 + Random().nextInt(2); // 4-5 minutos
    return (posicao - 1) * tempoMedioPorPosicao;
  }

  // Iniciar monitoramento da fila
  void _iniciarMonitoramento() {
    _timerAtualizacao = Timer.periodic(Duration(minutes: 1), (timer) {
      if (_naFila) {
        _atualizarPosicaoNaFila();
      }
    });
  }

  // Obter sugestões de reposicionamento
  Future<List<Map<String, dynamic>>> obterSugestoesReposicionamento(
      Position posicaoAtual
      ) async {
    List<Map<String, dynamic>> sugestoes = [];

    try {
      for (var ponto in _pontosEstrategicos) {
        final distancia = Geolocator.distanceBetween(
          posicaoAtual.latitude,
          posicaoAtual.longitude,
          ponto['lat'],
          ponto['lon'],
        ) / 1000; // em km

        final filaAtual = await _obterTamanhoFila(ponto['id']);
        final demandaEstimada = _estimarDemanda(ponto);

        final score = _calcularScorePonto(distancia, filaAtual, demandaEstimada);

        sugestoes.add({
          'ponto': ponto,
          'distancia': distancia,
          'filaAtual': filaAtual,
          'demandaEstimada': demandaEstimada,
          'tempoEspera': filaAtual * 4, // 4 min por posição
          'score': score,
        });
      }

      // Ordenar por score (melhor primeiro)
      sugestoes.sort((a, b) => b['score'].compareTo(a['score']));

      return sugestoes.take(5).toList();
    } catch (e) {
      print('Erro ao obter sugestões: $e');
      return [];
    }
  }

  // Obter tamanho da fila de um ponto
  Future<int> _obterTamanhoFila(String pontoId) async {
    try {
      final querySnapshot = await _firestore
          .collection('fila_virtual')
          .where('pontoId', isEqualTo: pontoId)
          .where('status', isEqualTo: 'aguardando')
          .get();

      return querySnapshot.docs.length;
    } catch (e) {
      return 0;
    }
  }

  // Estimar demanda de um ponto
  double _estimarDemanda(Map<String, dynamic> ponto) {
    final agora = DateTime.now();
    final hora = agora.hour;
    final diaSemana = agora.weekday;

    double demandaBase = ponto['demandaMedia'] ?? 0.5;

    // Ajustar por horário
    if (ponto['tipo'] == 'aeroporto') {
      if (hora >= 5 && hora <= 8 || hora >= 17 && hora <= 21) {
        demandaBase *= 1.5; // Picos de voo
      }
    } else if (ponto['tipo'] == 'shopping') {
      if (diaSemana >= 6) { // Final de semana
        demandaBase *= 1.3;
      }
      if (hora >= 14 && hora <= 22) {
        demandaBase *= 1.2;
      }
    }

    return demandaBase.clamp(0.1, 1.0);
  }

  // Calcular score do ponto
  double _calcularScorePonto(double distancia, int fila, double demanda) {
    double score = 100.0;

    // Penalizar distância (máximo 20 pontos)
    score -= (distancia * 2).clamp(0, 20);

    // Penalizar fila grande (máximo 30 pontos)
    score -= (fila * 3).clamp(0, 30);

    // Bonificar alta demanda (máximo 25 pontos)
    score += (demanda * 25);

    return score.clamp(0, 100);
  }

  // Métodos auxiliares para histórico do motorista
  Future<double> _obterAvaliacoesMotorista(String motoristaId) async {
    try {
      final doc = await _firestore.collection('motoristas').doc(motoristaId).get();
      if (doc.exists) {
        return (doc.data()!['avaliacao'] ?? 4.0).toDouble();
      }
    } catch (e) {
      print('Erro ao obter avaliações: $e');
    }
    return 4.0;
  }

  Future<int> _obterTempoComoMotorista(String motoristaId) async {
    try {
      final doc = await _firestore.collection('motoristas').doc(motoristaId).get();
      if (doc.exists) {
        final cadastro = (doc.data()!['data_cadastro'] as Timestamp?)?.toDate();
        if (cadastro != null) {
          return DateTime.now().difference(cadastro).inDays;
        }
      }
    } catch (e) {
      print('Erro ao obter tempo como motorista: $e');
    }
    return 0;
  }

  Future<int> _obterCorridasRecentes(String motoristaId) async {
    try {
      final inicioMes = DateTime(DateTime.now().year, DateTime.now().month, 1);
      final querySnapshot = await _firestore
          .collection('corridas')
          .where('motoristaId', isEqualTo: motoristaId)
          .where('concluidaEm', isGreaterThan: Timestamp.fromDate(inicioMes))
          .get();

      return querySnapshot.docs.length;
    } catch (e) {
      return 0;
    }
  }

  @override
  void dispose() {
    _timerAtualizacao?.cancel();
    super.dispose();
  }
}
