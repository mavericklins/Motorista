// lib/services/gamification_service.dart
import 'dart:async';
import 'package:vello_motorista/models/driver_goals.dart';

class GamificationService {
  const GamificationService();

  // Mapa acessado pela UI com achievement['icone'], ['titulo'], ['descricao'], ['pontos'].
  // Tipagem dinâmica nos valores para não quebrar indexação com [].
  static const Map<String, Map<String, dynamic>> availableAchievements = {
    'primeira_corrida': {
      'icone': '🚗',
      'titulo': 'Primeira corrida',
      'descricao': 'Complete a primeira corrida do dia',
      'pontos': 10,
    },
    'meta_diaria': {
      'icone': '🎯',
      'titulo': 'Meta diária',
      'descricao': 'Bata a meta diária de corridas',
      'pontos': 25,
    },
    // Adicione aqui outras chaves se a tela referenciar mais itens
  };

  // A tela espera Stream<DriverGoals?>. Entregar null é seguro e não muda visual.
  Stream<DriverGoals?> getDriverGoals() {
    return Stream<DriverGoals?>.value(null);
  }

  // Usado pela tela: retornar lista vazia segura.
  Future<List<Map<String, Object>>> getWeeklyRanking() async {
    return const <Map<String, Object>>[];
  }
}