import 'package:flutter/foundation.dart';

class GamificationService extends ChangeNotifier {
  /// Usado por goals_screen.dart (.entries)
  static const Map<String, Object> availableAchievements = <String, Object>{};
  int _currentLevel = 5;
  int _currentXP = 1250;
  double _levelProgress = 0.65;
  int _xpToNextLevel = 350;
  int _currentRank = 23;
  int _totalDrivers = 150;

  List<Map<String, dynamic>> _achievements = [
    {
      'title': 'Primeira Corrida',
      'icon': 0xe0b7, // Icons.directions_car
      'color': 0xFF4CAF50,
      'unlocked': true,
      'progress': 1.0,
      'description': 'Complete sua primeira corrida',
    },
    {
      'title': '100 Corridas',
      'icon': 0xe1a3, // Icons.emoji_events
      'color': 0xFFFFC107,
      'unlocked': true,
      'progress': 1.0,
      'description': 'Complete 100 corridas',
    },
    {
      'title': 'Estrela Brilhante',
      'icon': 0xe838, // Icons.star
      'color': 0xFFFF9800,
      'unlocked': false,
      'progress': 0.8,
      'description': 'Mantenha 5.0 de avaliação',
    },
  ];

  List<Map<String, dynamic>> _topDrivers = [
    {'name': 'Carlos Silva', 'rides': 450, 'xp': 4500},
    {'name': 'Maria Santos', 'rides': 420, 'xp': 4200},
    {'name': 'João Oliveira', 'rides': 380, 'xp': 3800},
    {'name': 'Ana Costa', 'rides': 350, 'xp': 3500},
    {'name': 'Pedro Lima', 'rides': 320, 'xp': 3200},
  ];

  Map<String, dynamic> _dailyChallenge = {
    'title': 'Complete 8 corridas hoje',
    'current': 3,
    'target': 8,
    'progress': 0.375,
    'reward': 150,
  };

  List<Map<String, dynamic>> _weeklyChallenges = [
    {
      'title': 'Motorista Consistente',
      'description': 'Trabalhe 5 dias consecutivos',
      'icon': 0xe8df, // Icons.timeline
      'current': 2,
      'target': 5,
      'progress': 0.4,
      'reward': 300,
      'timeLeft': '4 dias',
    },
    {
      'title': 'Ganhos Semanais',
      'description': 'Ganhe R\$ 800 esta semana',
      'icon': 0xe263, // Icons.attach_money
      'current': 450,
      'target': 800,
      'progress': 0.5625,
      'reward': 250,
      'timeLeft': '3 dias',
    },
  ];

  // Getters
  int get currentLevel => _currentLevel;
  int get currentXP => _currentXP;
  double get levelProgress => _levelProgress;
  int get xpToNextLevel => _xpToNextLevel;
  int get currentRank => _currentRank;
  int get totalDrivers => _totalDrivers;
  List<Map<String, dynamic>> get achievements => _achievements;
  List<Map<String, dynamic>> get topDrivers => _topDrivers;
  Map<String, dynamic> get dailyChallenge => _dailyChallenge;
  List<Map<String, dynamic>> get weeklyChallenges => _weeklyChallenges;

  Future<void> addXP(int xp) async {
    _currentXP += xp;
    _updateLevelProgress();
    notifyListeners();
  }

  void _updateLevelProgress() {
    int xpForCurrentLevel = (_currentLevel - 1) * 1000;
    int xpForNextLevel = _currentLevel * 1000;
    int xpInCurrentLevel = _currentXP - xpForCurrentLevel;
    int xpNeededForLevel = xpForNextLevel - xpForCurrentLevel;
    
    _levelProgress = xpInCurrentLevel / xpNeededForLevel;
    _xpToNextLevel = xpForNextLevel - _currentXP;
    
    if (_levelProgress >= 1.0) {
      _currentLevel++;
      _updateLevelProgress();
    }
  }

  Future<void> completeChallenge(String challengeId) async {
    // Implementar lógica de completar desafio
    notifyListeners();
  }

  Future<void> unlockAchievement(String achievementId) async {
    // Implementar lógica de desbloquear conquista
    notifyListeners();
  }

  // Implementações internas mínimas
  Stream<List<dynamic>> _driverGoalsInternal() async* {
    yield const <dynamic>[]; // vazio para não quebrar
  }

  Future<List<dynamic>> _weeklyRankingInternal() async {
    return const <dynamic>[]; // vazio para não quebrar
  }

  // Assinaturas públicas usadas nas telas
  Stream<List<T>> getDriverGoals<T>() => _driverGoalsInternal().cast<List<T>>();
  Future<List<T>> getWeeklyRanking<T>() async =>
      (await _weeklyRankingInternal()).cast<T>();
}