import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:geolocator/geolocator.dart';
import 'package:audioplayers/audioplayers.dart';
import '../models/ride.dart';
import 'notification_service.dart';
import 'package:flutter/material.dart';

class AdvancedSecurityService extends ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final AudioPlayer _audioPlayer = AudioPlayer();
  // Removed unused NotificationService instance

  Timer? _fatigueTimer;
  DateTime? _lastActivityTime;
  int _consecutiveDrivingMinutes = 0;
  bool _isRecordingEmergency = false;

  // Configurações de segurança
  static const int maxDrivingMinutesWithoutBreak = 120; // 2 horas
  static const int fatigueCheckIntervalMinutes = 15;
  static const int emergencyRecordingDurationSeconds = 120;

  // Inicializar monitoramento de fadiga
  void startFatigueMonitoring() {
    _fatigueTimer?.cancel();
    _lastActivityTime = DateTime.now();

    _fatigueTimer = Timer.periodic(
      Duration(minutes: fatigueCheckIntervalMinutes),
      _checkDriverFatigue
    );
    notifyListeners(); // Notificar que o monitoramento foi iniciado
  }

  void stopFatigueMonitoring() {
    _fatigueTimer?.cancel();
    _consecutiveDrivingMinutes = 0;
    notifyListeners(); // Notificar que o monitoramento foi parado
  }

  void _checkDriverFatigue(Timer timer) {
    _consecutiveDrivingMinutes += fatigueCheckIntervalMinutes;

    if (_consecutiveDrivingMinutes >= maxDrivingMinutesWithoutBreak) {
      _triggerFatigueAlert();
    }
    notifyListeners(); // Notificar sobre o status da fadiga
  }

  Future<void> _triggerFatigueAlert() async {
    // Notificar motorista sobre fadiga
    await NotificationService().showNotification(
      title: '⚠️ Alerta de Fadiga',
      body: 'Você está dirigindo há mais de 2 horas. É recomendado fazer uma pausa.',
    );

    // Tocar som de alerta
    await _audioPlayer.play(AssetSource('sounds/vello_notification.mp3'));

    // Registrar evento
    await _logSecurityEvent('fatigue_alert', {
      'consecutiveDrivingMinutes': _consecutiveDrivingMinutes,
      'timestamp': FieldValue.serverTimestamp(),
    });

    // Sugerir pontos de descanso próximos
    await _suggestRestPoints();
    notifyListeners(); // Notificar sobre o alerta de fadiga
  }

  Future<void> _suggestRestPoints() async {
    try {
      final position = await Geolocator.getCurrentPosition();

      // Buscar pontos de apoio próximos
      final pontos = await _firestore
          .collection('pontos_apoio')
          .where('ativo', isEqualTo: true)
          .get();

      final pontosProximos = <Map<String, dynamic>>[];

      for (final doc in pontos.docs) {
        final data = doc.data();
        final distance = Geolocator.distanceBetween(
          position.latitude,
          position.longitude,
          data['latitude'],
          data['longitude'],
        );

        if (distance <= 5000) { // 5km
          pontosProximos.add({
            ...data,
            'distance': distance,
            'id': doc.id,
          });
        }
      }

      if (pontosProximos.isNotEmpty) {
        // Ordenar por proximidade
        pontosProximos.sort((a, b) =>
          a['distance'].compareTo(b['distance'])
        );

        // Notificar sobre o ponto mais próximo
        final pontoProximo = pontosProximos.first;
        await NotificationService().showNotification(
          title: '📍 Ponto de Descanso Próximo',
          body: '${pontoProximo['nome']} - ${(pontoProximo['distance'] / 1000).toStringAsFixed(1)}km',
        );
      }
    } catch (e) {
      print('Erro ao sugerir pontos de descanso: $e');
    }
  }

  // Botão de pânico avançado
  Future<void> triggerEmergencyPanic({
    String? customMessage,
    bool includeLocation = true,
    bool includeAudio = true,
    bool includePhoto = false,
  }) async {
    try {
      final userId = _auth.currentUser?.uid;
      if (userId == null) return;

      print('🚨 EMERGÊNCIA ATIVADA - Iniciando protocolo de segurança');

      final emergencyData = <String, dynamic>{
        'motoristaId': userId,
        'timestamp': FieldValue.serverTimestamp(),
        'type': 'panic_button',
        'customMessage': customMessage,
        'status': 'active',
      };

      // 1. Capturar localização
      if (includeLocation) {
        try {
          final position = await Geolocator.getCurrentPosition(
            timeLimit: Duration(seconds: 10),
          );
          emergencyData['location'] = {
            'latitude': position.latitude,
            'longitude': position.longitude,
            'accuracy': position.accuracy,
            'timestamp': position.timestamp.toIso8601String(),
          };
          print('📍 Localização capturada: ${position.latitude}, ${position.longitude}');
        } catch (e) {
          print('Erro ao capturar localização: $e');
        }
      }

      // 2. Criar registro de emergência
      final emergencyRef = await _firestore
          .collection('emergencias')
          .add(emergencyData);

      print('📝 Emergência registrada: ${emergencyRef.id}');

      // 3. Iniciar gravação de áudio se solicitado
      if (includeAudio) {
        await _startEmergencyRecording(emergencyRef.id);
      }

      // 4. Notificar contatos de emergência
      await _notifyEmergencyContacts(emergencyRef.id, emergencyData);

      // 5. Notificar central de monitoramento
      await _notifyMonitoringCenter(emergencyRef.id, emergencyData);

      // 6. Ativar tracking contínuo de localização
      await _startContinuousLocationTracking(emergencyRef.id);

      // 7. Tocar som de emergência
      await _audioPlayer.play(AssetSource('sounds/vello_error.mp3'));
      notifyListeners(); // Notificar sobre a ativação do pânico

    } catch (e) {
      print('Erro crítico na ativação de emergência: $e');

      // Fallback: tentar notificação local mesmo com erro
      await NotificationService().showNotification(
        title: '🚨 EMERGÊNCIA ATIVADA',
        body: 'Protocolos de segurança em execução. Ajuda está a caminho.',
      );
    }
  }

  Future<void> _startEmergencyRecording(String emergencyId) async {
    if (_isRecordingEmergency) return;

    _isRecordingEmergency = true;
    print('🎤 Iniciando gravação de emergência...');

    try {
      // Em implementação real, usar plugin de gravação de áudio
      // Por enquanto, simular registro de início da gravação
      await _firestore
          .collection('emergencias')
          .doc(emergencyId)
          .update({
        'audioRecording': {
          'started': FieldValue.serverTimestamp(),
          'status': 'recording',
          'duration': emergencyRecordingDurationSeconds,
        }
      });

      // Simular parada da gravação após o tempo definido
      Timer(Duration(seconds: emergencyRecordingDurationSeconds), () async {
        _isRecordingEmergency = false;
        await _firestore
            .collection('emergencias')
            .doc(emergencyId)
            .update({
          'audioRecording.status': 'completed',
          'audioRecording.completedAt': FieldValue.serverTimestamp(),
        });
        print('🎤 Gravação de emergência concluída');
      });

    } catch (e) {
      print('Erro na gravação de emergência: $e');
      _isRecordingEmergency = false;
    }
  }

  Future<void> _notifyEmergencyContacts(String emergencyId, Map<String, dynamic> emergencyData) async {
    try {
      final userId = _auth.currentUser?.uid;
      if (userId == null) return;

      // Buscar contatos de emergência do motorista
      final motoristaDoc = await _firestore
          .collection('motoristas')
          .doc(userId)
          .get();

      if (!motoristaDoc.exists) return;

      final motorista = motoristaDoc.data()!;
      final contatosEmergencia = motorista['contatosEmergencia'] as List<dynamic>? ?? [];

      for (final contato in contatosEmergencia) {
        final nome = contato['nome'] ?? 'Contato';
        final telefone = contato['telefone'] ?? '';

        if (telefone.isNotEmpty) {
          // Criar notificação para contato
          await _firestore.collection('emergency_notifications').add({
            'emergencyId': emergencyId,
            'recipientName': nome,
            'recipientPhone': telefone,
            'driverName': motorista['nome'] ?? 'Motorista',
            'driverPhone': motorista['telefone'] ?? '',
            'message': 'EMERGÊNCIA: ${motorista['nome']} ativou o botão de pânico. Localização compartilhada.',
            'location': emergencyData['location'],
            'timestamp': FieldValue.serverTimestamp(),
            'status': 'pending',
          });
        }
      }

      print('📞 Notificações para contatos de emergência enviadas');
    } catch (e) {
      print('Erro ao notificar contatos de emergência: $e');
    }
  }

  Future<void> _notifyMonitoringCenter(String emergencyId, Map<String, dynamic> emergencyData) async {
    try {
      await _firestore.collection('monitoring_alerts').add({
        'emergencyId': emergencyId,
        'type': 'panic_button',
        'priority': 'HIGH',
        'driverId': _auth.currentUser?.uid,
        'data': emergencyData,
        'timestamp': FieldValue.serverTimestamp(),
        'status': 'new',
        'assignedOperator': null,
      });

      print('🏢 Central de monitoramento notificada');
    } catch (e) {
      print('Erro ao notificar central de monitoramento: $e');
    }
  }

  Future<void> _startContinuousLocationTracking(String emergencyId) async {
    print('📡 Iniciando rastreamento contínuo de localização...');

    Timer.periodic(Duration(seconds: 30), (timer) async {
      try {
        final position = await Geolocator.getCurrentPosition();

        await _firestore
            .collection('emergencias')
            .doc(emergencyId)
            .collection('location_tracking')
            .add({
          'latitude': position.latitude,
          'longitude': position.longitude,
          'accuracy': position.accuracy,
          'timestamp': FieldValue.serverTimestamp(),
        });

        // Parar tracking após 1 hora ou se emergência foi resolvida
        final emergencyDoc = await _firestore
            .collection('emergencias')
            .doc(emergencyId)
            .get();

        if (!emergencyDoc.exists ||
            emergencyDoc.data()?['status'] != 'active') {
          timer.cancel();
          print('📡 Rastreamento de emergência finalizado');
        }

      } catch (e) {
        print('Erro no tracking de localização: $e');
      }
    });
  }

  // Verificação de passageiros
  Future<PassengerVerification?> verifyPassenger(String passageiroId) async {
    try {
      final passageiroDoc = await _firestore
          .collection('usuarios')
          .doc(passageiroId)
          .get();

      if (!passageiroDoc.exists) return null;

      final data = passageiroDoc.data()!;

      // Calcular score de segurança
      final avaliacaoMedia = (data['avaliacaoMedia'] ?? 0.0).toDouble();
      final totalCorridas = data['totalCorridas'] ?? 0;
      final contaVerificada = data['contaVerificada'] ?? false;
      final documentoVerificado = data['documentoVerificado'] ?? false;
      final telefoneVerificado = data['telefoneVerificado'] ?? false;

      double safetyScore = 0.0;

      // Score baseado em avaliação
      if (avaliacaoMedia >= 4.5) safetyScore += 30;
      else if (avaliacaoMedia >= 4.0) safetyScore += 20;
      else if (avaliacaoMedia >= 3.5) safetyScore += 10;

      // Score baseado em corridas
      if (totalCorridas >= 50) safetyScore += 25;
      else if (totalCorridas >= 20) safetyScore += 15;
      else if (totalCorridas >= 5) safetyScore += 10;

      // Score baseado em verificações
      if (contaVerificada) safetyScore += 15;
      if (documentoVerificado) safetyScore += 15;
      if (telefoneVerificado) safetyScore += 15;

      // Buscar histórico de incidentes
      final incidentes = await _firestore
          .collection('incident_reports')
          .where('reportedUserId', isEqualTo: passageiroId)
          .where('status', isEqualTo: 'confirmed')
          .get();

      final numIncidentes = incidentes.docs.length;
      safetyScore -= (numIncidentes * 20); // Reduzir score por incidentes

      safetyScore = safetyScore.clamp(0.0, 100.0);

      String riskLevel;
      if (safetyScore >= 80) riskLevel = 'low';
      else if (safetyScore >= 60) riskLevel = 'medium';
      else if (safetyScore >= 40) riskLevel = 'high';
      else riskLevel = 'very_high';

      return PassengerVerification(
        passageiroId: passageiroId,
        nome: data['nome'] ?? 'Usuário',
        avaliacaoMedia: avaliacaoMedia,
        totalCorridas: totalCorridas,
        contaVerificada: contaVerificada,
        documentoVerificado: documentoVerificado,
        telefoneVerificado: telefoneVerificado,
        safetyScore: safetyScore,
        riskLevel: riskLevel,
        numIncidentes: numIncidentes,
        recomendacao: _getRecommendation(riskLevel, safetyScore),
      );

    } catch (e) {
      print('Erro ao verificar passageiro: $e');
      return null;
    }
  }

  String _getRecommendation(String riskLevel, double score) {
    switch (riskLevel) {
      case 'low':
        return 'Passageiro confiável. Pode aceitar com segurança.';
      case 'medium':
        return 'Passageiro regular. Mantenha atenção durante a corrida.';
      case 'high':
        return 'Atenção! Passageiro com histórico questionável.';
      case 'very_high':
        return 'ALERTA! Considere recusar esta corrida por segurança.';
      default:
        return 'Informações insuficientes para avaliação.';
    }
  }

  // Reportar incidente
  Future<bool> reportIncident({
    required String tipo,
    required String descricao,
    String? passageiroId,
    String? corridaId,
    List<String>? evidencias,
  }) async {
    try {
      final userId = _auth.currentUser?.uid;
      if (userId == null) return false;

      await _firestore.collection('incident_reports').add({
        'reporterId': userId,
        'reporterType': 'motorista',
        'reportedUserId': passageiroId,
        'corridaId': corridaId,
        'tipo': tipo,
        'descricao': descricao,
        'evidencias': evidencias ?? [],
        'status': 'pending_review',
        'timestamp': FieldValue.serverTimestamp(),
      });

      // Notificar equipe de segurança
      await _firestore.collection('safety_alerts').add({
        'type': 'incident_report',
        'priority': _getIncidentPriority(tipo),
        'reporterId': userId,
        'details': {
          'tipo': tipo,
          'descricao': descricao,
          'passageiroId': passageiroId,
          'corridaId': corridaId,
        },
        'timestamp': FieldValue.serverTimestamp(),
        'status': 'new',
      });

      return true;
    } catch (e) {
      print('Erro ao reportar incidente: $e');
      return false;
    }
  }

  String _getIncidentPriority(String tipo) {
    switch (tipo.toLowerCase()) {
      case 'agressao':
      case 'roubo':
      case 'assedio':
        return 'HIGH';
      case 'comportamento_inadequado':
      case 'danos_veiculo':
        return 'MEDIUM';
      default:
        return 'LOW';
    }
  }

  // Log de eventos de segurança
  Future<void> _logSecurityEvent(String eventType, Map<String, dynamic> data) async {
    try {
      final userId = _auth.currentUser?.uid;
      if (userId == null) return;

      await _firestore.collection('security_logs').add({
        'motoristaId': userId,
        'eventType': eventType,
        'data': data,
        'timestamp': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      print('Erro ao registrar evento de segurança: $e');
    }
  }

  // Finalizar emergência
  Future<void> resolveEmergency(String emergencyId, String resolution) async {
    try {
      await _firestore
          .collection('emergencias')
          .doc(emergencyId)
          .update({
        'status': 'resolved',
        'resolution': resolution,
        'resolvedAt': FieldValue.serverTimestamp(),
      });

      print('✅ Emergência resolvida: $emergencyId');
      notifyListeners(); // Notificar que a emergência foi resolvida
    } catch (e) {
      print('Erro ao resolver emergência: $e');
    }
  }

  @override
  void dispose() {
    _fatigueTimer?.cancel();
    _audioPlayer.dispose();
    super.dispose(); // Chamar o dispose da superclasse
  }
}

class PassengerVerification {
  final String passageiroId;
  final String nome;
  final double avaliacaoMedia;
  final int totalCorridas;
  final bool contaVerificada;
  final bool documentoVerificado;
  final bool telefoneVerificado;
  final double safetyScore;
  final String riskLevel;
  final int numIncidentes;
  final String recomendacao;

  PassengerVerification({
    required this.passageiroId,
    required this.nome,
    required this.avaliacaoMedia,
    required this.totalCorridas,
    required this.contaVerificada,
    required this.documentoVerificado,
    required this.telefoneVerificado,
    required this.safetyScore,
    required this.riskLevel,
    required this.numIncidentes,
    required this.recomendacao,
  });
}