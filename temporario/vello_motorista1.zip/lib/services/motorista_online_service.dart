import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:geolocator/geolocator.dart';
import 'dart:async';

class MotoristaOnlineService extends ChangeNotifier {
  static final MotoristaOnlineService _instance = MotoristaOnlineService._internal();
  factory MotoristaOnlineService() => _instance;
  MotoristaOnlineService._internal();

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  Timer? _heartbeatTimer;
  Timer? _locationTimer;
  String? _currentUserId;
  bool _isOnline = false;
  Position? _currentPosition;

  // Getters
  bool get isOnline => _isOnline;
  Position? get currentPosition => _currentPosition;
  String? get currentUserId => _currentUserId;

  // Inicializar o serviço
  Future<void> initialize({String? userId}) async {
    // SEMPRE usar usuário autenticado do Firebase Auth
    User? currentUser = _auth.currentUser;
    
    if (currentUser != null) {
      _currentUserId = currentUser.uid;
      print('🚗 Usando usuário autenticado: ${currentUser.email}');
    } else {
      print('❌ ERRO: Usuário não está autenticado no Firebase Auth');
      return;
    }
    
    print('🚗 MotoristaOnlineService inicializado para usuário: $_currentUserId');
    
    // Tentar obter localização inicial
    await _updateCurrentLocation();
    
    notifyListeners();
  }

  // Toggle do status online/offline
  Future<void> toggleOnlineStatus() async {
    if (_isOnline) {
      await goOffline();
    } else {
      await goOnline();
    }
  }

  // Ficar online
  Future<void> goOnline() async {
    if (_currentUserId == null) {
      print('❌ Erro: usuário não inicializado');
      return;
    }

    try {
      _isOnline = true;
      
      // Obter localização atual
      await _updateCurrentLocation();
      
      // Atualizar status no Firestore com estrutura PADRONIZADA
      await _updateFirestoreStatus('online');
      
      // Iniciar heartbeat (a cada 30 segundos)
      _startHeartbeat();
      
      // Iniciar atualização de localização (a cada 15 segundos)
      _startLocationUpdates();
      
      notifyListeners();
      print('✅ Motorista ficou ONLINE');
    } catch (e) {
      print('❌ Erro ao ficar online: $e');
      _isOnline = false;
      notifyListeners();
      rethrow;
    }
  }

  // Ficar offline
  Future<void> goOffline() async {
    if (_currentUserId == null) return;

    try {
      _isOnline = false;
      
      // Parar timers
      _heartbeatTimer?.cancel();
      _locationTimer?.cancel();
      
      // Atualizar status no Firestore
      await _updateFirestoreStatus('offline');
      
      notifyListeners();
      print('🔴 Motorista ficou OFFLINE');
    } catch (e) {
      print('❌ Erro ao ficar offline: $e');
      rethrow;
    }
  }

  // Atualizar status no Firestore - ESTRUTURA PADRONIZADA
  Future<void> _updateFirestoreStatus(String status) async {
    if (_currentUserId == null) return;

    try {
      User? currentUser = _auth.currentUser;
      if (currentUser == null) {
        print('❌ Usuário não autenticado');
        return;
      }
      
      // ESTRUTURA PADRONIZADA para compatibilidade com painel e app passageiro
      final data = <String, dynamic>{
        'status': status,
        'disponivel': status == 'online', // Campo essencial para busca
        'em_corrida': false,
        'ultimo_heartbeat': FieldValue.serverTimestamp(),
        'ultimo_update': FieldValue.serverTimestamp(),
      };

      // Adicionar localização no formato CORRETO (objeto localizacao)
      if (_currentPosition != null) {
        data['localizacao'] = {
          'latitude': _currentPosition!.latitude,
          'longitude': _currentPosition!.longitude,
          'timestamp': FieldValue.serverTimestamp(),
        };
        
        // Manter campos separados para compatibilidade
        data['latitude'] = _currentPosition!.latitude;
        data['longitude'] = _currentPosition!.longitude;
      }

      // Verificar se o documento existe
      final docRef = _firestore.collection('motoristas').doc(_currentUserId!);
      final docSnapshot = await docRef.get();

      if (docSnapshot.exists) {
        // Atualizar documento existente - PRESERVAR dados existentes
        await docRef.update(data);
        print('📍 Status atualizado no documento existente');
      } else {
        // Criar novo documento com dados COMPLETOS
        // CORREÇÃO: Verificar se _currentUserId não é null antes de usar
        if (_currentUserId != null) {
          data['id'] = _currentUserId!; // Usar ! para garantir que não é null
        }
        data['nome'] = currentUser.displayName ?? 'Motorista ${currentUser.email?.split('@')[0]}';
        data['email'] = currentUser.email ?? '${_currentUserId}@vello.com';
        data['telefone'] = '(11) 99999-9999';
        data['veiculo'] = {
          'modelo': 'Honda Civic',
          'placa': 'ABC-1234',
          'cor': 'Branco',
          'ano': 2020
        };
        data['avaliacaoMedia'] = 4.8;
        data['totalCorridas'] = 156;
        data['data_cadastro'] = FieldValue.serverTimestamp();
        data['categoria'] = 'Padrão';
        
        await docRef.set(data);
        print('📍 Novo documento criado com estrutura padronizada');
      }
      
      print('📍 Status sincronizado: $status | Disponível: ${status == 'online'}');
    } catch (e) {
      print('❌ Erro ao sincronizar com Firebase: $e');
      rethrow;
    }
  }

  // Atualizar localização atual
  Future<void> _updateCurrentLocation() async {
    try {
      // Verificar permissões
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          print('❌ Permissão de localização negada');
          return;
        }
      }

      if (permission == LocationPermission.deniedForever) {
        print('❌ Permissão de localização negada permanentemente');
        return;
      }

      // Obter posição atual
      _currentPosition = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
        timeLimit: Duration(seconds: 10),
      );
      
      print('📍 Localização obtida: ${_currentPosition!.latitude}, ${_currentPosition!.longitude}');
      notifyListeners();
    } catch (e) {
      print('❌ Erro ao obter localização: $e');
    }
  }

  // Iniciar heartbeat
  void _startHeartbeat() {
    _heartbeatTimer?.cancel();
    _heartbeatTimer = Timer.periodic(Duration(seconds: 30), (timer) {
      if (_isOnline) {
        _sendHeartbeat();
      } else {
        timer.cancel();
      }
    });
  }

  // Enviar heartbeat
  Future<void> _sendHeartbeat() async {
    if (_currentUserId == null || !_isOnline) return;

    try {
      await _firestore.collection('motoristas').doc(_currentUserId!).update({
        'ultimo_heartbeat': FieldValue.serverTimestamp(),
        'status': 'online', // Garantir que status permanece online
        'disponivel': true, // Garantir que permanece disponível
      });
      
      print('💓 Heartbeat enviado - Status mantido: online');
    } catch (e) {
      print('❌ Erro no heartbeat: $e');
    }
  }

  // Iniciar atualizações de localização
  void _startLocationUpdates() {
    _locationTimer?.cancel();
    _locationTimer = Timer.periodic(Duration(seconds: 15), (timer) {
      if (_isOnline) {
        _updateLocationInFirestore();
      } else {
        timer.cancel();
      }
    });
  }

  // Atualizar localização no Firestore - FORMATO PADRONIZADO
  Future<void> _updateLocationInFirestore() async {
    if (_currentUserId == null || !_isOnline) return;

    try {
      await _updateCurrentLocation();
      
      if (_currentPosition != null) {
        await _firestore.collection('motoristas').doc(_currentUserId!).update({
          // Formato objeto (esperado pelo app passageiro)
          'localizacao': {
            'latitude': _currentPosition!.latitude,
            'longitude': _currentPosition!.longitude,
            'timestamp': FieldValue.serverTimestamp(),
          },
          // Campos separados (compatibilidade)
          'latitude': _currentPosition!.latitude,
          'longitude': _currentPosition!.longitude,
          'ultimo_update': FieldValue.serverTimestamp(),
        });
        
        print('📍 Localização sincronizada em ambos os formatos');
      }
    } catch (e) {
      print('❌ Erro ao sincronizar localização: $e');
    }
  }

  // Marcar como em corrida
  Future<void> setInRide(bool inRide) async {
    if (_currentUserId == null) return;

    try {
      await _firestore.collection('motoristas').doc(_currentUserId!).update({
        'em_corrida': inRide,
        'disponivel': !inRide, // Se está em corrida, não está disponível
        'ultimo_update': FieldValue.serverTimestamp(),
      });
      
      print('🚗 Status corrida atualizado: ${inRide ? "Em corrida" : "Disponível"}');
      notifyListeners();
    } catch (e) {
      print('❌ Erro ao atualizar status de corrida: $e');
    }
  }

  // Cleanup
  void dispose() {
    _heartbeatTimer?.cancel();
    _locationTimer?.cancel();
    if (_isOnline) {
      goOffline();
    }
    super.dispose();
  }
}

