import 'package:flutter/foundation.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AuthService extends ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  bool _isLoading = false;
  bool get isLoading => _isLoading;

  String? errorMessage;

  User? get currentUser => _auth.currentUser;
  bool get isLoggedIn => currentUser != null;

  // 🔐 LOGIN
  Future<bool> signInWithEmailAndPassword(String email, String password) async {
    try {
      _isLoading = true;
      notifyListeners();

      final credential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );

      if (credential.user != null) {
        final doc = await _firestore
            .collection('motoristas')
            .doc(credential.user!.uid)
            .get();

        if (doc.exists) {
          _isLoading = false;
          notifyListeners();
          return true;
        } else {
          await _auth.signOut();
          _isLoading = false;
          notifyListeners();
          return false;
        }
      }

      _isLoading = false;
      notifyListeners();
      return false;
    } catch (e) {
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // 🆕 CADASTRO
  Future<bool> createAccount(String email, String password) async {
    try {
      _isLoading = true;
      notifyListeners();

      await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      _isLoading = false;
      errorMessage = null;
      notifyListeners();
      return true;
    } on FirebaseAuthException catch (e) {
      errorMessage = e.message;
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // 🚪 LOGOUT
  Future<void> signOut() async {
    await _auth.signOut();
    notifyListeners();
  }

  // 📤 SALVAR MOTORISTA PARA APROVAÇÃO
  Future<void> salvarMotoristaParaAprovacao({
    required String uid,
    required String nome,
    required String email,
    required String cpf,
    required String modelo,
    required String ano,
    required String placa,
    required String cnhUrl,
    required String selfieUrl,
    required String carroUrl,
  }) async {
    await _firestore.collection('motoristas_aguardando_aprovacao').doc(uid).set({
      'nome': nome,
      'email': email,
      'cpf': cpf,
      'modelo': modelo,
      'ano': ano,
      'placa': placa,
      'cnhUrl': cnhUrl,
      'selfieUrl': selfieUrl,
      'carroUrl': carroUrl,
      'status': 'pendente',
      'criadoEm': FieldValue.serverTimestamp(),
    });
  }
}
