import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'dart:async';

/// Serviço Firebase para receber corridas em tempo real com popup
class FirebaseCorridasService {
  static FirebaseCorridasService? _instance;
  static FirebaseCorridasService get instance => _instance ??= FirebaseCorridasService._();
  
  FirebaseCorridasService._();

  StreamSubscription<QuerySnapshot>? _corridasSubscription;
  BuildContext? _context;
  Function(String, Map<String, dynamic>)? _onCorridaDisponivel;
  bool _isListening = false;
  String? _currentMotoristaId;
  Timer? _heartbeatTimer;

  /// Inicializar o serviço com callback para popup
  void initialize(BuildContext context, Function(String, Map<String, dynamic>) onCorridaDisponivel) {
    _context = context;
    _onCorridaDisponivel = onCorridaDisponivel;
    _currentMotoristaId = FirebaseAuth.instance.currentUser?.uid;
    
    print('🚗 FirebaseCorridasService: Inicializando para motorista $_currentMotoristaId');
    
    if (_currentMotoristaId != null) {
      _startHeartbeat();
    }
  }

  /// Parar o serviço
  void dispose() {
    print('🚗 FirebaseCorridasService: Finalizando serviço');
    _stopListening();
    _stopHeartbeat();
    _context = null;
    _onCorridaDisponivel = null;
    _currentMotoristaId = null;
  }

  /// Iniciar escuta de corridas
  void _startListening() {
    if (_isListening || _currentMotoristaId == null) return;
    
    print('🚗 FirebaseCorridasService: Iniciando escuta de corridas...');
    _isListening = true;

    // Escutar corridas pendentes em tempo real
    _corridasSubscription = FirebaseFirestore.instance
        .collection('corridas')
        .where('status', isEqualTo: 'pendente')
        .snapshots()
        .listen(
          _onCorridasUpdate,
          onError: _onError,
        );
  }

  /// Parar escuta de corridas
  void _stopListening() {
    if (!_isListening) return;
    
    print('🚗 FirebaseCorridasService: Parando escuta de corridas...');
    _isListening = false;
    _corridasSubscription?.cancel();
    _corridasSubscription = null;
  }

  /// Callback quando corridas são atualizadas
  void _onCorridasUpdate(QuerySnapshot snapshot) {
    print('🚗 FirebaseCorridasService: ${snapshot.docs.length} corridas pendentes encontradas');
    
    for (var change in snapshot.docChanges) {
      if (change.type == DocumentChangeType.added) {
        final corridaData = change.doc.data() as Map<String, dynamic>?;
        if (corridaData != null) {
          final corridaId = change.doc.id;
          print('🚗 Nova corrida disponível: $corridaId');
          
          // Chamar callback para mostrar popup
          if (_onCorridaDisponivel != null) {
            _onCorridaDisponivel!(corridaId, corridaData);
          }
        }
      }
    }
  }

  /// Aceitar corrida
  Future<void> aceitarCorrida(String corridaId, Map<String, dynamic> corridaData) async {
    if (_currentMotoristaId == null) return;

    try {
      print('🚗 Aceitando corrida: $corridaId');

      // Buscar dados do motorista
      final motoristaDoc = await FirebaseFirestore.instance
          .collection('motoristas')
          .doc(_currentMotoristaId)
          .get();

      if (!motoristaDoc.exists) {
        throw Exception('Dados do motorista não encontrados');
      }

      final motoristaData = motoristaDoc.data()!;

      // Atualizar corrida com dados do motorista
      await FirebaseFirestore.instance
          .collection('corridas')
          .doc(corridaId)
          .update({
        'status': 'em_andamento',
        'motoristaId': _currentMotoristaId,
        'nomeMotorista': motoristaData['nome'] ?? 'Motorista',
        'telefoneMotorista': motoristaData['telefone'] ?? '',
        'modeloVeiculo': motoristaData['veiculo']?['modelo'] ?? '',
        'placaVeiculo': motoristaData['veiculo']?['placa'] ?? '',
        'corVeiculo': motoristaData['veiculo']?['cor'] ?? '',
        'aceitaEm': FieldValue.serverTimestamp(),
      });

      // Atualizar status do motorista
      await FirebaseFirestore.instance
          .collection('motoristas')
          .doc(_currentMotoristaId)
          .update({
        'status': 'ocupado',
        'corridaAtual': corridaId,
        'ultimaAtualizacao': FieldValue.serverTimestamp(),
      });

      // Mostrar confirmação
      if (_context != null) {
        ScaffoldMessenger.of(_context!).showSnackBar(
          SnackBar(
            content: Row(
              children: [
                Icon(Icons.check_circle, color: Colors.white),
                SizedBox(width: 8),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text('Corrida aceita com sucesso!', 
                        style: TextStyle(fontWeight: FontWeight.bold)),
                      Text('Dirija-se ao local de origem'),
                    ],
                  ),
                ),
              ],
            ),
            backgroundColor: Colors.green,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            duration: Duration(seconds: 4),
          ),
        );
      }

      print('✅ Corrida aceita com sucesso: $corridaId');

    } catch (e) {
      print('❌ Erro ao aceitar corrida: $e');
      
      if (_context != null) {
        ScaffoldMessenger.of(_context!).showSnackBar(
          SnackBar(
            content: Text('Erro ao aceitar corrida: $e'),
            backgroundColor: Colors.red,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          ),
        );
      }
    }
  }

  /// Callback de erro
  void _onError(error) {
    print('❌ FirebaseCorridasService erro: $error');
    
    if (_context != null) {
      ScaffoldMessenger.of(_context!).showSnackBar(
        SnackBar(
          content: Text('Erro na conexão com Firebase: $error'),
          backgroundColor: Colors.red,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      );
    }
  }

  /// Iniciar heartbeat para manter conexão ativa
  void _startHeartbeat() {
    _heartbeatTimer?.cancel();
    
    _heartbeatTimer = Timer.periodic(Duration(minutes: 1), (timer) {
      if (_currentMotoristaId != null) {
        FirebaseFirestore.instance
            .collection('motoristas')
            .doc(_currentMotoristaId)
            .update({
          'ultimaAtualizacao': FieldValue.serverTimestamp(),
        }).catchError((e) {
          print('❌ Erro no heartbeat: $e');
        });
      }
    });
  }

  /// Parar heartbeat
  void _stopHeartbeat() {
    _heartbeatTimer?.cancel();
    _heartbeatTimer = null;
  }

  /// Atualizar status online/offline
  void updateOnlineStatus(bool isOnline) {
    print('🚗 FirebaseCorridasService: Status alterado para ${isOnline ? "ONLINE" : "OFFLINE"}');
    
    if (isOnline) {
      _startListening();
    } else {
      _stopListening();
    }
  }
}

