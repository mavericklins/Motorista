import 'package:flutter/material.dart';

class VelloColors {
  // Cores principais da identidade Vello
  static const Color laranja = Color(0xFFFF6B35);
  static const Color azul = Color(0xFF2E3A59);
  static const Color azulEscuro = Color(0xFF1B3A57);
  
  // Cores complementares
  static const Color branco = Color(0xFFFFFFFF);
  static const Color preto = Color(0xFF000000);
  static const Color cinza = Color(0xFF6B7280);
  static const Color cinzaClaro = Color(0xFFF3F4F6);
  static const Color cinzaEscuro = Color(0xFF374151);
  static const Color creme = Color(0xFFF8F9FA);
  
  // Cores de status
  static const Color sucesso = Color(0xFF10B981);
  static const Color erro = Color(0xFFEF4444);
  static const Color aviso = Color(0xFFF59E0B);
  static const Color info = Color(0xFF3B82F6);
  
  // Gradientes
  static const LinearGradient gradientePrincipal = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [laranja, azul],
  );
  
  static const LinearGradient gradienteSecundario = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [azul, azulEscuro],
  );
  
  static const LinearGradient gradienteLaranja = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFFFF8A50), laranja],
  );
  
  // Cores com transparência
  static const Color laranjaTransparente = Color(0x80FF6B35);
  static const Color azulTransparente = Color(0x802E3A59);
  static const Color pretoTransparente = Color(0x80000000);
  static const Color brancoTransparente = Color(0x80FFFFFF);
}

