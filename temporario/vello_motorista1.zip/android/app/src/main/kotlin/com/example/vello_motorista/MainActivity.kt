package com.example.vello_motorista

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
