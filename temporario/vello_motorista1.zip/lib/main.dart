import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:provider/provider.dart';
import 'screens/perfil/perfil_screen.dart';
import 'screens/historico/historico_screen.dart';
import 'screens/configuracoes/configuracoes_screen.dart';
import 'constants/app_colors.dart';
import 'services/auth_service.dart';
import 'screens/auth/splash_screen.dart';
import 'screens/auth/login_screen.dart';
import 'screens/home/home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const VelloMotoristaApp());
}

class VelloMotoristaApp extends StatelessWidget {
  const VelloMotoristaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => AuthService(),
      child: MaterialApp(
        title: 'Vello Motorista',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(
            seedColor: VelloColors.laranja,
            primary: VelloColors.laranja,
            secondary: VelloColors.azul,
            surface: VelloColors.branco,
            background: VelloColors.creme,
          ),
          appBarTheme: const AppBarTheme(
            backgroundColor: VelloColors.laranja,
            foregroundColor: VelloColors.branco,
            elevation: 0,
            centerTitle: true,
          ),
          elevatedButtonTheme: ElevatedButtonThemeData(
            style: ElevatedButton.styleFrom(
              backgroundColor: VelloColors.laranja,
              foregroundColor: VelloColors.branco,
              elevation: 2,
              padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: VelloColors.cinzaClaro,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide.none,
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: VelloColors.laranja, width: 2),
            ),
          ),
          cardTheme: CardThemeData(
            elevation: 4,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            color: VelloColors.branco,
          ),
        ),
        home: const SplashScreen(),
        routes: {
          '/login': (context) => const LoginScreen(),
          '/home': (context) => const HomeScreen(),
          '/perfil': (context) => const PerfilScreen(),
          '/historico': (context) => const HistoricoScreen(),
          '/configuracoes': (context) => const ConfiguracoesScreen(),

        },
      ),
    );
  }
}

