
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:geolocator/geolocator.dart';
import '../../services/advanced_security_service.dart';
import '../../constants/app_colors.dart';

class SOSScreen extends StatefulWidget {
  @override
  _SOSScreenState createState() => _SOSScreenState();
}

class _SOSScreenState extends State<SOSScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _pulseAnimation;
  bool _isEmergencyActive = false;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: Duration(seconds: 1),
      vsync: this,
    );
    _pulseAnimation = Tween<double>(
      begin: 1.0,
      end: 1.2,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _isEmergencyActive ? Colors.red.shade50 : AppColors.background,
      appBar: AppBar(
        title: Text('Sistema SOS'),
        backgroundColor: _isEmergencyActive ? Colors.red : AppColors.primary,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: Icon(Icons.settings),
            onPressed: () => _showSOSSettings(context),
          ),
        ],
      ),
      body: Consumer<AdvancedSecurityService>(
        builder: (context, service, child) {
          return Padding(
            padding: EdgeInsets.all(24),
            child: Column(
              children: [
                // Status de emergência
                if (_isEmergencyActive)
                  Container(
                    width: double.infinity,
                    padding: EdgeInsets.all(16),
                    margin: EdgeInsets.only(bottom: 24),
                    decoration: BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(
                      children: [
                        Icon(
                          Icons.warning,
                          color: Colors.white,
                          size: 32,
                        ),
                        SizedBox(height: 8),
                        Text(
                          'EMERGÊNCIA ATIVA',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          'Autoridades foram notificadas',
                          style: TextStyle(
                            color: Colors.white70,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  ),

                // Botão SOS principal
                Expanded(
                  child: Center(
                    child: GestureDetector(
                      onLongPress: () => _activateEmergency(context, service),
                      onTap: () => _showSOSInstructions(context),
                      child: AnimatedBuilder(
                        animation: _pulseAnimation,
                        builder: (context, child) {
                          return Transform.scale(
                            scale: _isEmergencyActive ? _pulseAnimation.value : 1.0,
                            child: Container(
                              width: 200,
                              height: 200,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: RadialGradient(
                                  colors: _isEmergencyActive
                                      ? [Colors.red.shade300, Colors.red.shade700]
                                      : [Colors.red.shade400, Colors.red.shade600],
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.red.withOpacity(0.4),
                                    blurRadius: 20,
                                    spreadRadius: 5,
                                  ),
                                ],
                              ),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    Icons.emergency,
                                    size: 60,
                                    color: Colors.white,
                                  ),
                                  SizedBox(height: 8),
                                  Text(
                                    'SOS',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 24,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  SizedBox(height: 4),
                                  Text(
                                    _isEmergencyActive ? 'ATIVO' : 'Manter pressionado',
                                    style: TextStyle(
                                      color: Colors.white70,
                                      fontSize: 12,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                ),

                // Opções rápidas
                Container(
                  padding: EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.1),
                        blurRadius: 5,
                        offset: Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Opções de Segurança',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: AppColors.primary,
                        ),
                      ),
                      SizedBox(height: 16),
                      _buildQuickOption(
                        icon: Icons.location_on,
                        title: 'Compartilhar Localização',
                        subtitle: 'Enviar localização para contatos',
                        onTap: () => service.shareLocation(),
                      ),
                      Divider(),
                      _buildQuickOption(
                        icon: Icons.phone,
                        title: 'Ligar para 190',
                        subtitle: 'Polícia Militar',
                        onTap: () => service.callEmergency('190'),
                      ),
                      Divider(),
                      _buildQuickOption(
                        icon: Icons.local_hospital,
                        title: 'Ligar para 192',
                        subtitle: 'SAMU',
                        onTap: () => service.callEmergency('192'),
                      ),
                      Divider(),
                      _buildQuickOption(
                        icon: Icons.message,
                        title: 'Mensagem Automática',
                        subtitle: 'SMS para contatos de emergência',
                        onTap: () => service.sendEmergencyMessage(),
                      ),
                    ],
                  ),
                ),

                SizedBox(height: 24),

                // Cancelar emergência
                if (_isEmergencyActive)
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () => _cancelEmergency(service),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.grey,
                        padding: EdgeInsets.symmetric(vertical: 16),
                      ),
                      child: Text(
                        'Cancelar Emergência',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildQuickOption({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return ListTile(
      leading: Icon(icon, color: AppColors.primary),
      title: Text(title),
      subtitle: Text(subtitle),
      trailing: Icon(Icons.arrow_forward_ios, size: 16),
      onTap: onTap,
    );
  }

  void _activateEmergency(BuildContext context, AdvancedSecurityService service) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Ativar SOS?'),
        content: Text(
          'Isso irá:\n'
          '• Enviar sua localização\n'
          '• Notificar contatos de emergência\n'
          '• Alertar autoridades\n'
          '• Iniciar gravação de áudio/vídeo',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancelar'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              setState(() {
                _isEmergencyActive = true;
              });
              _animationController.repeat(reverse: true);
              service.activateEmergency();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
            ),
            child: Text('Ativar SOS'),
          ),
        ],
      ),
    );
  }

  void _cancelEmergency(AdvancedSecurityService service) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Cancelar Emergência?'),
        content: Text('Tem certeza que deseja cancelar o alerta de emergência?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Não'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              setState(() {
                _isEmergencyActive = false;
              });
              _animationController.stop();
              service.cancelEmergency();
            },
            child: Text('Sim, Cancelar'),
          ),
        ],
      ),
    );
  }

  void _showSOSInstructions(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Como usar o SOS'),
        content: Text(
          'Para ativar o SOS:\n\n'
          '1. Mantenha pressionado o botão vermelho por 3 segundos\n'
          '2. Confirme a ativação\n'
          '3. O sistema irá automaticamente:\n'
          '   • Enviar sua localização\n'
          '   • Notificar contatos\n'
          '   • Alertar autoridades\n\n'
          'Use apenas em emergências reais!',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Entendi'),
          ),
        ],
      ),
    );
  }

  void _showSOSSettings(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => Scaffold(
          appBar: AppBar(
            title: Text('Configurações SOS'),
            backgroundColor: AppColors.primary,
            foregroundColor: Colors.white,
          ),
          body: Padding(
            padding: EdgeInsets.all(16),
            child: Column(
              children: [
                ListTile(
                  leading: Icon(Icons.contacts),
                  title: Text('Contatos de Emergência'),
                  subtitle: Text('Configurar contatos para notificação'),
                  trailing: Icon(Icons.arrow_forward_ios),
                  onTap: () {},
                ),
                ListTile(
                  leading: Icon(Icons.record_voice_over),
                  title: Text('Gravação Automática'),
                  subtitle: Text('Gravar áudio/vídeo durante emergência'),
                  trailing: Switch(value: true, onChanged: (value) {}),
                ),
                ListTile(
                  leading: Icon(Icons.location_on),
                  title: Text('Compartilhamento de Localização'),
                  subtitle: Text('Enviar localização automaticamente'),
                  trailing: Switch(value: true, onChanged: (value) {}),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
